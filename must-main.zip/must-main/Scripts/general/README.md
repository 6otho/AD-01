# 引用地址
```
https://github.com/KOP-XIAO/QuantumultX/blob/master/Scripts/IP_API.js
https://github.com/KOP-XIAO/QuantumultX/blob/master/Scripts/resource-parser.js
https://github.com/KOP-XIAO/QuantumultX/blob/master/Scripts/streaming-ui-check.js
```